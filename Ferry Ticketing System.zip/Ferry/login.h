#ifndef LOGIN_H
#define LOGIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ANSI_COLOR_RESET "\e[0m"
#define ANSI_COLOR_BOLD "\e[1m"
#define ANSI_COLOR_UNDERLINE "\e[4m"
#define ANSI_COLOR_RED "\e[0;31m"
#define ANSI_COLOR_GREEN "\e[0;32m"
#define ANSI_COLOR_YELLOW "\e[0;33m"
#define ANSI_COLOR_BLUE "\e[0;34m"
#define ANSI_COLOR_MAGENTA "\e[0;35m"
#define ANSI_COLOR_CYAN "\e[0;36m"

struct Login
{
    char username[20];
    char password[20];
};


void loginAction()
{
    struct Login login;
    struct Login saved[20];

    FILE* fp = fopen("logins.txt", "r");
    if (fp == NULL) {
        printf("Could not open the file.\n");
    }


    for (int i = 0; i < 20; i++) {
        fscanf(fp, "%s %s", saved[i].username, saved[i].password);
    }

    fclose(fp);
    
    while(1)
    {
        printf("                   ");
        printf(ANSI_COLOR_BOLD ANSI_COLOR_GREEN ANSI_COLOR_UNDERLINE"Welcome to Login"ANSI_COLOR_RESET);
        printf("        \n\n");
        

        
        printf(ANSI_COLOR_YELLOW "Username: " ANSI_COLOR_RESET);
        scanf("%s", login.username);

        printf(ANSI_COLOR_YELLOW "Password: " ANSI_COLOR_RESET);
        scanf("%s", login.password);

        
        

        for(int i = 0; i < 20; i++)
        {
            if(strcmp(login.username, saved[i].username) == 0 && strcmp(login.password, saved[i].password) == 0)
            {
                printf("Login successful!\n");
                return;
            }
        }

        printf("Invalid username or password. Please try again.\n");
    }

    

    
}




#endif