#ifndef SPLASH_H
#define SPLASH_H

#include <stdio.h>
#include <stdlib.h>

#define ANSI_COLOR_RESET "\e[0m"
#define ANSI_COLOR_BOLD "\e[1m"
#define ANSI_COLOR_UNDERLINE "\e[4m"
#define ANSI_COLOR_RED "\e[0;31m"
#define ANSI_COLOR_GREEN "\e[0;32m"
#define ANSI_COLOR_YELLOW "\e[0;33m"
#define ANSI_COLOR_BLUE "\e[0;34m"
#define ANSI_COLOR_MAGENTA "\e[0;35m"
#define ANSI_COLOR_CYAN "\e[0;36m"

void splash()
{
    FILE* fp = fopen("splash.txt", "r");

    if (fp == NULL) {
        printf("Could not open the file.\n");
    }


    char line[150];
    
    while (fgets(line, sizeof(line), fp)) {
        if(line[0] == 'W')
        {
            printf(ANSI_COLOR_BLUE);
        }
        printf("%s", line);
    }
    printf(ANSI_COLOR_RESET);

    fclose(fp);
}

void namescreen()
{
    FILE* fp2 = fopen("ferrygo.txt", "r");

    if (fp2 == NULL) {
        printf("Could not open the file.\n");
    }

    char ch2;
    printf(ANSI_COLOR_RED);
    while ((ch2 = fgetc(fp2)) != EOF) {
        printf("%c", ch2);
    }

    printf(ANSI_COLOR_RESET ANSI_COLOR_BOLD ANSI_COLOR_GREEN "A Ferry Ticketing System" ANSI_COLOR_RESET);

    fclose(fp2);
}

#endif