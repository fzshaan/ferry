#include <stdio.h>
#include <stdlib.h>
//#include <dos.h>
#include <unistd.h>               //Only dos.h wasn't working so I added this
#include "splash.h"
#include "login.h"
#include "menu.h"

int main()
{
    splash();

    sleep(3);
    system("clear");

    namescreen();

    sleep(3);
    system("clear");

    loginAction();

    sleep(1);
    system("clear");

    MenuDisplay();


    return 0;
}