#ifndef MENU_H
#define MENU_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ANSI_COLOR_RESET "\e[0m"
#define ANSI_COLOR_BOLD "\e[1m"
#define ANSI_COLOR_UNDERLINE "\e[4m"
#define ANSI_COLOR_RED "\e[0;31m"
#define ANSI_COLOR_GREEN "\e[0;32m"
#define ANSI_COLOR_YELLOW "\e[0;33m"
#define ANSI_COLOR_BLUE "\e[0;34m"
#define ANSI_COLOR_MAGENTA "\e[0;35m"
#define ANSI_COLOR_CYAN "\e[0;36m"     //These are ANSI Codes I added to make the text more lively


struct Route {
    char start[20];
    char middle[20];                                    //A struct to store the route a ferry will take
    char end[20];
};

struct Schedule {
    char date[20];
    char time[20];                                      //A struct to store the specific schedule entry of a ferry
    struct Route route;
};

struct Ticket {
    char name[20];
    char seat[20];
    double price;                                       //A struct to store the ticket details of a passenger who has booked a ticket
    char date[20];
    char time[20];
    struct Route route;
};



void ViewRoutes(struct Route routes[], int count)
{
    printf("               ");
    printf(ANSI_COLOR_BOLD ANSI_COLOR_GREEN ANSI_COLOR_UNDERLINE"Available Routes"ANSI_COLOR_RESET);
    printf("        \n\n");
    
    for(int i = 0; i < 10; i++)
    {
        printf(ANSI_COLOR_BLUE "%d) " ANSI_COLOR_RESET, i + 1);
        printf(ANSI_COLOR_RED "%s " ANSI_COLOR_RESET, routes[i].start);
        printf("to ");
        printf(ANSI_COLOR_MAGENTA "%s " ANSI_COLOR_RESET, routes[i].end);               //This function displays the routes available
        printf("via ");
        printf(ANSI_COLOR_CYAN "%s\n" ANSI_COLOR_RESET, routes[i].middle);
    }

    printf("\n");
    int i;
    do
    {
        printf(ANSI_COLOR_YELLOW "Enter 1 to exit to main menu: " ANSI_COLOR_RESET);    //This is a do while loop to ensure the user enters 1 to exit to main menu
        scanf("%d", &i);
    } while (i != 1);
    
    printf("\n");
}

void ViewSchedule(struct Schedule schedule[], int count)
{
    printf("               ");
    printf(ANSI_COLOR_BOLD ANSI_COLOR_GREEN ANSI_COLOR_UNDERLINE"Today's Schedule"ANSI_COLOR_RESET);
    printf("        \n\n");
    
    for(int i = 0; i < 20; i++)
    {
        printf(ANSI_COLOR_BLUE "%s   " ANSI_COLOR_RESET, schedule[i].date);
        printf(ANSI_COLOR_RED "%s   " ANSI_COLOR_RESET, schedule[i].time);
        printf(ANSI_COLOR_YELLOW "%s " ANSI_COLOR_RESET, schedule[i].route.start);       //This function displays the daily schedule of the ferries
        printf("to ");
        printf(ANSI_COLOR_MAGENTA "%s " ANSI_COLOR_RESET, schedule[i].route.end);
        printf("via ");
        printf(ANSI_COLOR_CYAN "%s\n" ANSI_COLOR_RESET, schedule[i].route.middle);
    }

    printf("\n");
    int i;
    do
    {
        printf(ANSI_COLOR_YELLOW "Enter 1 to exit to main menu: " ANSI_COLOR_RESET);
        scanf("%d", &i);
    } while (i != 1);
    
    printf("\n");
}

struct Ticket BookTicket(struct Route routes[], struct Schedule schedule[], int routecount, int schedulecount)
{
    struct Ticket ticket;
    
    printf("               ");
    printf(ANSI_COLOR_BOLD ANSI_COLOR_GREEN ANSI_COLOR_UNDERLINE"Book Ticket"ANSI_COLOR_RESET);
    printf("        \n\n");
    
    //Name Entry
    printf(ANSI_COLOR_YELLOW "Enter your name: " ANSI_COLOR_RESET);
    getchar();                                                                  //This getchar() is used to clear the input buffer from the previous scanf
    fgets(ticket.name, 20, stdin);                                              //Used fgets as scanf can't take spaces in a string as input 
    ticket.name[strlen(ticket.name) - 1] = '\0';                                //Removing the \n character from the end of the string
    printf("\n");

    //Route Selection
    printf(ANSI_COLOR_MAGENTA"Available Routes: \n"ANSI_COLOR_RESET);
    for(int i = 0; i < 10; i++)
    {
        printf(ANSI_COLOR_BLUE "%d) " ANSI_COLOR_RESET, i + 1);
        printf(ANSI_COLOR_RED "%s " ANSI_COLOR_RESET, routes[i].start);
        printf("to ");
        printf(ANSI_COLOR_MAGENTA "%s " ANSI_COLOR_RESET, routes[i].end);        //Displaying available routes
        printf("via ");
        printf(ANSI_COLOR_CYAN "%s\n" ANSI_COLOR_RESET, routes[i].middle);
    }
    printf("\n");
    int route_num = 0;
    do
    {
        printf(ANSI_COLOR_YELLOW "Select your route: " ANSI_COLOR_RESET);
        scanf("%d", &route_num);
    } while (route_num < 1 || route_num > 10);
    ticket.route = routes[route_num - 1];
    printf("\n");

    //Time Selection
    char time1[20], time2[20];
    int timeflag = 0;
    for(int i = 0; i < 20; i++)
    {
        if(strcmp(ticket.route.start, schedule[i].route.start) == 0 && strcmp(ticket.route.end, schedule[i].route.end) == 0 && strcmp(ticket.route.middle, schedule[i].route.middle) == 0)
        {
            //Comparing the route selected by the user with the schedule to find the available times and storing them to display it to the user
            if(timeflag == 0)
            {
                strcpy(time1, schedule[i].time);
                timeflag = 1;
            }
            else
            {
                strcpy(time2, schedule[i].time);
                break;
            }
        }
    }
    
    printf(ANSI_COLOR_MAGENTA"Available Times:\n"ANSI_COLOR_RESET);
    printf(ANSI_COLOR_BLUE"1)"ANSI_COLOR_RESET" %s\n"ANSI_COLOR_BLUE"2)"ANSI_COLOR_RESET" %s\n", time1, time2);
    printf("\n");
    int time_num = 0;
    do
    {
        printf(ANSI_COLOR_YELLOW "Select time: " ANSI_COLOR_RESET);
        scanf("%d", &time_num);
    } while (time_num < 1 || time_num > 2);
    printf("\n");
    if(time_num == 1)
    {
        strcpy(ticket.time, time1);
    }
    else
    {
        strcpy(ticket.time, time2);
    }

    //Date Selection
    strcpy(ticket.date, schedule[0].date);

    //Seat Selection
    int seat_num = 0;
    printf(ANSI_COLOR_MAGENTA"Seats:\n"ANSI_COLOR_RESET ANSI_COLOR_BLUE"1)"ANSI_COLOR_RESET" Premium\n"ANSI_COLOR_BLUE"2)"ANSI_COLOR_RESET" Executive\n"ANSI_COLOR_BLUE"3)"ANSI_COLOR_RESET" Economy\n\n");
    do
    {
        printf(ANSI_COLOR_YELLOW "Select your seat: " ANSI_COLOR_RESET);
        scanf("%d", &seat_num);
    } while (seat_num < 1 || seat_num > 3);
    
    if(seat_num == 1)
    {
        strcpy(ticket.seat, "Premium");
        ticket.price = 1000;
    }
    else if(seat_num == 2)
    {
        strcpy(ticket.seat, "Executive");
        ticket.price = 800;
    }
    else
    {
        strcpy(ticket.seat, "Economy");
        ticket.price = 500;
    }
    printf("\n");
    
    //Displaying Ticket Details
    printf("\n");
    printf(ANSI_COLOR_BOLD ANSI_COLOR_GREEN ANSI_COLOR_UNDERLINE"Ticket Details:\n\n"ANSI_COLOR_RESET);
    printf(ANSI_COLOR_BLUE "Name: " ANSI_COLOR_RESET);
    printf(ANSI_COLOR_RED "%s\n" ANSI_COLOR_RESET, ticket.name);
    printf(ANSI_COLOR_BLUE "Seat: " ANSI_COLOR_RESET);
    printf(ANSI_COLOR_RED "%s\n" ANSI_COLOR_RESET, ticket.seat);
    printf(ANSI_COLOR_BLUE "Price: " ANSI_COLOR_RESET);
    printf(ANSI_COLOR_RED "%0.7lf\n" ANSI_COLOR_RESET, ticket.price);
    printf(ANSI_COLOR_BLUE "Date: " ANSI_COLOR_RESET);
    printf(ANSI_COLOR_RED "%s\n" ANSI_COLOR_RESET, ticket.date);
    printf(ANSI_COLOR_BLUE "Time: " ANSI_COLOR_RESET);
    printf(ANSI_COLOR_RED "%s\n" ANSI_COLOR_RESET, ticket.time);
    printf(ANSI_COLOR_BLUE "Route: " ANSI_COLOR_RESET);
    printf(ANSI_COLOR_RED "%s " ANSI_COLOR_RESET, ticket.route.start);
    printf("to ");
    printf(ANSI_COLOR_MAGENTA "%s " ANSI_COLOR_RESET, ticket.route.end);
    printf("via ");
    printf(ANSI_COLOR_CYAN "%s\n" ANSI_COLOR_RESET, ticket.route.middle);
    

    printf("\n");
    int i;
    do
    {
        printf(ANSI_COLOR_YELLOW "Enter 1 to exit to main menu: " ANSI_COLOR_RESET);
        scanf("%d", &i);
    } while (i != 1);
    
    printf("\n");

    return ticket;

}

void ViewBookings(struct Ticket tickets[], int count)
{
    printf("               ");
    printf(ANSI_COLOR_BOLD ANSI_COLOR_GREEN ANSI_COLOR_UNDERLINE"Your Bookings"ANSI_COLOR_RESET);
    printf("        \n\n");
    
    for(int i = 0; i < count; i++)
    {
        printf(ANSI_COLOR_BLUE "%d) " ANSI_COLOR_RESET, i + 1);
        printf(ANSI_COLOR_RED "%s " ANSI_COLOR_RESET, tickets[i].name);
        printf("has booked ");
        printf(ANSI_COLOR_MAGENTA "%s " ANSI_COLOR_RESET, tickets[i].seat);
        printf("seat for ");
        printf(ANSI_COLOR_CYAN "%s " ANSI_COLOR_RESET, tickets[i].route.start);
        printf("to ");
        printf(ANSI_COLOR_MAGENTA "%s " ANSI_COLOR_RESET, tickets[i].route.end);
        printf("via ");
        printf(ANSI_COLOR_CYAN "%s " ANSI_COLOR_RESET, tickets[i].route.middle);
        printf("on ");
        printf(ANSI_COLOR_RED "%s " ANSI_COLOR_RESET, tickets[i].date);
        printf("at ");
        printf(ANSI_COLOR_RED "%s\n" ANSI_COLOR_RESET, tickets[i].time);
    }

    printf("\n");
    int i;
    do
    {
        printf(ANSI_COLOR_YELLOW "Enter 1 to exit to main menu: " ANSI_COLOR_RESET);
        scanf("%d", &i);
    } while (i != 1);
    
    printf("\n");
}



void MenuDisplay()
{
    struct Route routes[10];            //Holding all the routes
    struct Schedule schedule[20];       //Holding the daily schedule
    struct Ticket tickets[10];          //Holding the tickets booked by the user
    int ticketCount = 0;                //Holding the number of tickets booked by the user

    //Reading the routes and schedule from the files
    FILE* fp = fopen("routes.txt", "r");
    if (fp == NULL) {
        printf("Could not open the file.\n");
    }


    for (int i = 0; i < 10; i++) {
        fscanf(fp, "%s %s %s", routes[i].start, routes[i].middle, routes[i].end);
    }

    fclose(fp);

    fp = fopen("schedule.txt", "r");
    if (fp == NULL) {
        printf("Could not open the file.\n");
    }


    for (int i = 0; i < 20; i++) {
        fscanf(fp, "%s %s %s %s %s", schedule[i].date, schedule[i].time, schedule[i].route.start, schedule[i].route.middle, schedule[i].route.end);
    }

    fclose(fp);

    //Main Menu
    while(1)
    {
        printf("               ");
        printf(ANSI_COLOR_BOLD ANSI_COLOR_GREEN ANSI_COLOR_UNDERLINE"MAIN MENU"ANSI_COLOR_RESET);
        printf("        \n\n");
        
        printf(ANSI_COLOR_BLUE "1) " ANSI_COLOR_RESET);
        printf("View Routes\n");
        printf(ANSI_COLOR_BLUE "2) " ANSI_COLOR_RESET);
        printf("View Schedule\n");
        printf(ANSI_COLOR_BLUE "3) " ANSI_COLOR_RESET);
        printf("Book a Ticket\n");
        printf(ANSI_COLOR_BLUE "4) " ANSI_COLOR_RESET);
        printf("View Bookings\n");
        printf(ANSI_COLOR_BLUE "5) " ANSI_COLOR_RESET);
        printf("Exit\n\n");

        int choice;
        printf(ANSI_COLOR_YELLOW "Enter your choice: " ANSI_COLOR_RESET);
        scanf("%d", &choice);
        printf("\n");

        switch(choice)
        {
            case 1:
                ViewRoutes(routes, 10);
                break;
            case 2:
                ViewSchedule(schedule, 20);
                break;
            case 3:
                tickets[ticketCount] = BookTicket(routes, schedule, 10, 20);
                ticketCount++;
                break;
            case 4:
                if(ticketCount == 0)
                {
                    printf("You have no bookings.\n\n");
                }
                else{
                    ViewBookings(tickets, ticketCount);
                }
                break;
            case 5:
                exit(0);
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    
    }

}

#endif